function getUsuarios() {
    return JSON.parse(localStorage.getItem('usuarios'));
}

// Função para salvar os usuários no localStorage
function saveUsuarios(usuarios) {
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
}

// Função para obter o usuário logado (presumindo que você tem um mecanismo para isso)
function getUsuarioLogado() {
    return localStorage.getItem('usuarioLogado'); // Aqui você teria uma chave que identifica o usuário logado
}
let usuarios = getUsuarios();
let usuarioLogado = getUsuarioLogado();
let usuario = usuarios.find(u => u.usuario === usuarioLogado);
let pontuacao = 0;
let tempo = 0;
let bolinha = document.getElementById('bolinha');
let jogo = document.getElementById('jogo');
let apagar = document.getElementById('dificuldade');
let jogarNovamente = document.getElementById('jogaDnovo');
let pontuacaoFinal = document.getElementById('scorerec');
let highscore = 0;
let dific = 0;
let ok = document.getElementById('ok');
let desistir = document.getElementById('desistir');
let intervalId = null;
let pontuacaoDesis = document.getElementById('PontoD');
let dificuldade = 0;
let higheasy = document.getElementById('ptfacil').textContent


jogarNovamente.style.display = 'none';
desistir.style.display = 'none';

//Clamp
const min = 50
const max = 80

//Clamp number between two values with the following line:
const clamp = (num, min, max) => Math.min(Math.max(num, min), max)

//

let pontua =[
    {
        jogadores: "",
        senha:"",
        ptnfacil: 0,
        ptnmedio: 0,
        ptndificil: 0

    }
]; 



document.getElementById("facil").addEventListener('click', function() {
    pontuacao = 0;
    ptnfacil = 0;
    tempo = 10;
    iniciarJogo();
    apagar.style.display = 'none';
    jogarNovamente.style.display = 'none';
    desistir.style.display = 'none';
    dific = 0;
    dificuldade = 0;
});

document.getElementById("medio").addEventListener('click', function() {
    pontuacao = 0;
    ptnmedio = 0;
    tempo = 7;
    iniciarJogo();
    apagar.style.display = 'none';
    jogarNovamente.style.display = 'none';
    desistir.style.display = 'none';
    dific = 1;   
    dificuldade = 1;
});

document.getElementById("dificil").addEventListener('click', function() {
    pontuacao = 0;
    ptndificil = 0;
    tempo = 2;
    iniciarJogo();
    apagar.style.display = 'none';
    jogarNovamente.style.display = 'none';
    desistir.style.display = 'none';
    dific = 2;
    dificuldade = 2;
});



function iniciarJogo() {
    pontuacao = 0;
    jogo.style.display = 'block'; 
    document.getElementById('pontuacao').innerText = `Pontuação: ${pontuacao}`;
    intervalId = setInterval(() => {
        if (pontuacao > 0) {
            pontuacao--;
            document.getElementById('pontuacao').innerText = `Pontuação: ${pontuacao}`;
        } else {
            jogo.style.display = 'none';
            jogarNovamente.style.display = 'block';
        }
    }, tempo * 1000);
}
    
    
    bolinha.addEventListener('click', () => {
        pontuacao++;
        document.getElementById('pontuacao').innerText = `Pontuação: ${pontuacao}`;
        bolinha.style.top = `${Math.floor((Math.random() * 50) + 25)}%`;
        //bolinha.style.bottom = ${Math.random() * 100}%;
        bolinha.style.left = `${Math.floor((Math.random() * 50) + 25)}%`;
        //bolinha.style.right = ${Math.random() * 1}%;

        if (pontuacao >= highscore){

            highscore = pontuacao;
            if (dificuldade == 0){
                ptnfacil = pontuacao;
            }
            if(dificuldade == 1){
                ptnmedio = highscore;
            }
            if(dificuldade == 2){
                ptndificil = highscore;
            }
            pontuacaoFinal.textContent = `SCORE:` + highscore;
        
       };
         
            if (pontuacao >= 10) {
                 bolinha.style.backgroundImage = 'url("sol.png")';
                 bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 20) {
                bolinha.style.backgroundImage = 'url("mercurio1.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 30) {
                bolinha.style.backgroundImage = 'url("venus.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 40) {
                bolinha.style.backgroundImage = 'url("terra.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 50) {
                bolinha.style.backgroundImage = 'url("marte.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 60) {
                bolinha.style.backgroundImage = 'url("jupiter.png")';
                bolinha.style.backgroundSize = 'contain';
                bolinha.style.borderImageWidth
            }
            if (pontuacao >= 70) {
                bolinha.style.backgroundImage = 'url("saturno.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 80) {
                bolinha.style.backgroundImage = 'url("urano.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 90) {
                bolinha.style.backgroundImage = 'url("netuno.png")';
                bolinha.style.backgroundSize = 'contain';
            }

            

        });
    
    
   
//botao recomeçar
document.getElementById('volta').addEventListener('click', function novamente(){ 
    jogo.style.display = 'none';
    apagar.style.display = 'block';
    jogarNovamente.style.display = 'none';
    location.reload();
    pontuacaoFinal.textContent = `Pontuação: ` + pontuacao ;
    higheasy.textContent = 'highscore facil: ' + ptnfacil;
    document.getElementById('ptmedio').textContent = 'highscore medio' + ptnmedio;
    document.getElementById('ptdificil').textContent = 'highscore dificil' + ptndificil;
    alert('Teste');
});

//botao voltar
document.getElementById('voltar').addEventListener('click', function     (){
    jogo.style.display = 'none';
    apagar.style.display = 'none';
    jogarNovamente.style.display = 'none';
    desistir.style.display = 'block';
    clearInterval(intervalId);
    pontuacaoDesis.textContent = `Esta é sua pontuação: ` + pontuacao ;
    higheasy.textContent = 'highscore facil: ' + ptnfacil;
    document.getElementById('ptmedio').textContent = 'highscore medio' + ptnmedio;
    document.getElementById('ptdificil').textContent = 'highscore dificil' + ptndificil;
    alert('Teste');
});

//botao obrigado
document.getElementById('ok').addEventListener('click', function desistiu(){
    desistir.style.display = 'none';
    jogo.style.display = 'none';
    apagar.style.display = 'none';
    pontuacao = 0;
    location.reload();
    jogarNovamente.style.display = 'none';
});